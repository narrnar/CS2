//Daren Sathasivam
//CSCI-2 0122 Professor Ambrosio
//Organize the cpp file provided under multiple different classes and .h files to create a game. A user can input different keys to either stand, move, or shoot towards a certain direction and the objective is to survive for as many loops or "steps" as possible. A user can also input "q" to quit the game. The player is indicated by an "@" and a robot is indicated by an "R" unless there are multiple, which is then indicated by the number of robots occupying that spot. A player dies if they are in the same position as a "Robot" and is indicated by a *.

// zion.cpp
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "Game.h"
#include "Arena.h"
#include "Player.h"
#include "Robot.h"
#include "globals.h"

using namespace std;


///////////////////////////////////////////////////////////////////////////
//  main()
///////////////////////////////////////////////////////////////////////////
int main()
{
      // Initialize the random number generator.  (You don't need to
      // understand how this works.)
    srand(static_cast<unsigned int>(time(0)));
      // Create a game
      // Use this instead to create a mini-game:   Game g(3, 3, 2);
    Game g(15, 18, 80);
      // Play the game
    g.play();
}

