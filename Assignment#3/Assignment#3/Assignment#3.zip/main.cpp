//Daren Sathasivam
//CSCI-2, 0122,
//Assignment #3
//Utilize LinkedList class and implement several different functions similar to that of the ones taught within the lectures. Solution should output the same as sample given. 

#include <iostream>
#include <string>
#include "LinkedList.h"

using namespace std;

int main()
{
    //pass parameter by const reference
    LinkedList ls;
    ls.insertToRear("Carl");
    ls.insertToRear("Hariette");
    ls.insertToRear("Eddie");
    ls.insertToRear("Laura");
    ls.insertToRear("Judy");
    ls.insertToRear("Steve");
     for (int k = 0; k < ls.size(); k++)
    {
       string x;
       ls.get(k, x);
       cout << x << endl;
    }
    
    //print list and reversed list
    LinkedList ls2;
    ls2.insertToRear("Cory");
    ls2.insertToRear("Topanga");
    ls2.insertToRear("Shawn");
    ls2.insertToRear("Eric");
     
    ls2.printList();
    ls2.printReverse();
    
    //append function
    LinkedList e1;
    e1.insertToRear("devoe");
    e1.insertToRear("biv");
    e1.insertToRear("bell");
    LinkedList e2;
    e2.insertToRear("Big Boi");
    e2.insertToRear("Andre");
    e1.append(e2);  // adds contents of e2 to the end of e1
    string s;
    assert(e1.size() == 5  &&  e1.get(3, s)  &&  s == "Big Boi");
    assert(e2.size() == 2  &&  e2.get(1, s)  &&  s == "Andre");
    e1.printList();
    
    
    //reverseList function
    LinkedList e3;
    e3.insertToRear("Norm");
    e3.insertToRear("Cliff");
    e3.insertToRear("Carla");
    e3.insertToRear("Sam");
    e3.reverseList();  // reverses the contents of e3
    string s3;
    assert(e3.size() == 4  &&  e3.get(0, s3)  &&  s3 == "Sam");
    e3.printList();
    
    
    //swap function
    LinkedList e4;
    e4.insertToRear("D");
    e4.insertToRear("C");
    e4.insertToRear("B");
    e4.insertToRear("A");
    LinkedList e5;
    e5.insertToRear("Z");
    e5.insertToRear("Y");
    e5.insertToRear("X");
    e4.swap(e5);  // exchange contents of e4 and e5
    string s5;
    assert(e4.size() == 3  &&  e4.get(0, s5)  &&  s5 == "Z");
    assert(e5.size() == 4  &&  e5.get(2, s5)  &&  s5 == "B");
    e4.printList();
    e5.printList();
}
